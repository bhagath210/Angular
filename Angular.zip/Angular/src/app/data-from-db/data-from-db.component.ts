import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-from-db',
  templateUrl: './data-from-db.component.html',
  styleUrls: ['./data-from-db.component.css']
})
export class DataFromDBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
