import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataFromDBComponent } from './data-from-db.component';

describe('DataFromDBComponent', () => {
  let component: DataFromDBComponent;
  let fixture: ComponentFixture<DataFromDBComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataFromDBComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataFromDBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
