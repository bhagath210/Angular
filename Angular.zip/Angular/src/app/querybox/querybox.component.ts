import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-querybox',
  templateUrl: './querybox.component.html',
  styleUrls: ['./querybox.component.css']
})
export class QueryboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}