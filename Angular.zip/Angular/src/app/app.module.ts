import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { QueryboxComponent } from './querybox/querybox.component';
import { RouterModule, Routes } from '@angular/router';
import { ProductVideosComponent } from './product-videos/product-videos.component';
import { DataFromDBComponent } from './data-from-db/data-from-db.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/Home', pathMatch:'full'},
  { path: 'QueryBox', component: QueryboxComponent },
  { path:'Home', component: MainComponent},
  { path:'ProductVideos', component: ProductVideosComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    HeaderComponent,
    FooterComponent,
    QueryboxComponent,
    ProductVideosComponent,
    DataFromDBComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
