import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-videos',
  templateUrl: './product-videos.component.html',
  styleUrls: ['./product-videos.component.css']
})
export class ProductVideosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
